-- $Id: 01-050-addUserLanguage.sql 5224 2011-07-05 05:34:27Z krivopustov $
-- Description: sec_user.language_ field

alter table SEC_USER add LANGUAGE_ varchar(10)
^
