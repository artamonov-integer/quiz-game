-- $Id: 121102-dropSaltColumn.sql 9487 2012-11-02 14:22:53Z artamonov $
-- Description: drop SALT column in SEC_USER

alter table SEC_USER drop column SALT^